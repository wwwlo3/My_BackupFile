before(() => {
  cy.clearCookies();
});
